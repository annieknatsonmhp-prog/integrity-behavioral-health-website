# Integrity Behavioral Health & Compliance Center
Professional website for a court-trusted behavioral health and compliance therapy agency.

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run locally:
   ```bash
   npm run dev
   ```

3. Deploy on [Vercel](https://vercel.com) or [Netlify](https://netlify.com).
