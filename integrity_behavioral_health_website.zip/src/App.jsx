import React from "react";

export default function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Lato, sans-serif", backgroundColor: "#f8f7f3", color: "#2b2b2b" }}>
      <h1 style={{ fontFamily: "Playfair Display, serif" }}>Integrity Behavioral Health & Compliance Center</h1>
      <p><em>“Where ethics, accountability, and healing meet.”</em></p>
      <p>This website is under development. Please check back soon for full access.</p>
    </div>
  );
}
